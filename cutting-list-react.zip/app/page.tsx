'use client';
import { useState } from "react";

export default function CuttingListApp() {
  const [width, setWidth] = useState(1200);
  const [height, setHeight] = useState(1200);

  const calc = {
    doubleJamb: height,
    doubleHeader: width - 27,
    doubleSill: width - 27,
    topBottomRail: (width / 2 - 65.5).toFixed(1),
    lockstile: height - 46,
    interlocker: height - 46,
    screenFrame: height - 48,
    glassWidth: (width / 2 - 72).toFixed(1),
    glassHeight: height - 123,
  };

  return (
    <div style={{ maxWidth: "600px", margin: "auto", padding: "20px", fontFamily: "Arial" }}>
      <h1 style={{ fontSize: "24px", fontWeight: "bold", marginBottom: "20px" }}>
        Cutting List Generator
      </h1>

      <label>
        Width (mm):
        <input
          type="number"
          value={width}
          onChange={(e) => setWidth(parseFloat(e.target.value))}
          style={{ width: "100%", marginBottom: "10px", padding: "8px" }}
        />
      </label>

      <label>
        Height (mm):
        <input
          type="number"
          value={height}
          onChange={(e) => setHeight(parseFloat(e.target.value))}
          style={{ width: "100%", marginBottom: "20px", padding: "8px" }}
        />
      </label>

      <div style={{ background: "#f9f9f9", padding: "20px", borderRadius: "8px" }}>
        <h2>Cutting List</h2>
        <ul>
          <li>Double Jamb (2 pcs): {calc.doubleJamb} mm</li>
          <li>Double Header (1 pc): {calc.doubleHeader} mm</li>
          <li>Double Sill (1 pc): {calc.doubleSill} mm</li>
          <li>Top/Bottom Rail (4 pcs): {calc.topBottomRail} mm</li>
          <li>Lockstile (2 pcs): {calc.lockstile} mm</li>
          <li>Interlocker (2 pcs): {calc.interlocker} mm</li>
          <li>Screen Frame (2 pcs): {calc.screenFrame} mm</li>
          <li>Glass (2 pcs): {calc.glassWidth} mm × {calc.glassHeight} mm</li>
          <li>Center Lock: 1 set</li>
          <li>Rollers: 4 pcs</li>
          <li>4 Accessory Types: 2 sets each</li>
        </ul>
      </div>
    </div>
  );
}