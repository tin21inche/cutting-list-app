# Cutting List Generator (React Version)

This is a simple React-based cutting list calculator for 2-panel sliding windows.
Enter height and width to get the cutting sizes for aluminum, glass, and accessories.

Deployed easily with Vercel.